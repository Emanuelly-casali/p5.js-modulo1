function setup() {
  createCanvas(1000, 1000);// criando cenário
  background('white');// cor do cenário
}

function draw() { // fumção de desenho
  
 stroke('rgb(196,34,150)') // cor da borda do retângulo 
  fill('rgb(141,1,141)') //cor do retângulo
  
  //console.log(mouseIsPressed);
  
  if (mouseIsPressed){// quando o mouse é clicado o retângulo aparece
     rect(mouseX, mouseY,30 , 40 )// posição do retângulo e o tamanho 
  }
}